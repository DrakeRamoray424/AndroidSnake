package com.example.nnelanut.snakeapplication.enums;

/**
 * Created by 123 on 12/8/2017.
 */

public enum TileType {
    Nothing,
    Wall,
    SnakeHead,
    SnakeTail,
    Apple
}
