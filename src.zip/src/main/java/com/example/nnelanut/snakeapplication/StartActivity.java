//START ACTIVITY
package com.example.nnelanut.snakeapplication;

import android.content.Intent;
import android.content.res.Configuration;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class StartActivity extends AppCompatActivity {



    private EditText nameText;
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        Configuration config = getResources().getConfiguration();
        onConfigurationChanged(config);

        nameText = (EditText) findViewById(R.id.userName);
        nameText.setText("");
        //PLACE TO ENTER NAME

    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        modifyLayout(newConfig);
    }

    public void modifyLayout(Configuration newConfig) {

        if(newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            setContentView(R.layout.activity_start);
        }

        if(newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setContentView(R.layout.activity_start_horizontal);
        }
    }

    public void startGame(View v) {


        if (nameText.getText().toString() == "") name = "John Doe";

        else name = nameText.getText().toString();

            Intent myIntent = new Intent(this, MainActivity.class);

            myIntent.putExtra("userName", name);

            startActivity(myIntent);




    }



    public void quitGame(View v) {


        //finishActivity(0);
       // System.exit(0);

        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
