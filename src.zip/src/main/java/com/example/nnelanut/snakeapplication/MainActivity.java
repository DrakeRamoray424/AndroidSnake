//MAIN ACTIVITY
package com.example.nnelanut.snakeapplication;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.util.Random;


import com.example.nnelanut.snakeapplication.classes.UserScore;
import com.example.nnelanut.snakeapplication.engine.GameEngine;
import com.example.nnelanut.snakeapplication.enums.Direction;
import com.example.nnelanut.snakeapplication.enums.GameState;
import com.example.nnelanut.snakeapplication.views.SnakeView;


public class MainActivity extends AppCompatActivity implements View.OnTouchListener{

    private GameEngine gameEngine;
    private SnakeView snakeView;
    private RelativeLayout rl;
    private final Handler handler = new Handler();
    private final long updateDelay = 150;   //speed of snake
    private Intent endGameIntent;
    MediaPlayer snakeSong;
    private String userName;
    private int score;

    private float prevX, prevY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);





        gameEngine = new GameEngine();
        gameEngine.initGame();

        snakeView = new SnakeView(this, null);
        snakeView.setOnTouchListener(this);

        rl = new RelativeLayout(this);

        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.FILL_PARENT, RelativeLayout.LayoutParams.FILL_PARENT);

        rl.addView(snakeView);

        Random rand = new Random();
        int song = rand.nextInt((2 - 1) + 1) + 1;

        switch (song) {
            case 1:

                snakeSong = MediaPlayer.create(MainActivity.this, R.raw.agrabah_theme_1 );
                break;

            case 2:
                snakeSong = MediaPlayer.create(MainActivity.this, R.raw.agrabah_theme_2 );
                break;

            default:
                snakeSong = MediaPlayer.create(MainActivity.this, R.raw.agrabah_theme_1 );
                break;

        }


        snakeSong.start();
        snakeSong.setLooping(true);

        Bundle myBundle = getIntent().getExtras();

        userName = myBundle.getString("userName");


        setContentView(rl, lp);


        startUpdateHandler();



    }

    private void startUpdateHandler() {
        //UPDATES SNAKE POSITION UNTIL DEAD


        handler.postDelayed(new Runnable() {



            public void run() {

                gameEngine.Update();



                snakeView.setSnakeViewMap(gameEngine.getMap());
                snakeView.invalidate();

               if (gameEngine.getCurrentGameState() == GameState.Running) {
                    handler.postDelayed(this,updateDelay);
                }


                if (gameEngine.getCurrentGameState() == GameState.Lost) {
                    snakeSong.stop();
                    OnGameLost();
                }





            }

        }, updateDelay);




    }

    private void OnGameLost() {
        Toast.makeText(this, "You lost, score: " + gameEngine.getScore(), Toast.LENGTH_SHORT).show();

        endGameIntent = new Intent(this, ScoreListActivity.class);
        score = gameEngine.getScore();

        //SENDS DATA TO SCORE LIST
       endGameIntent.putExtra("name", userName);
       endGameIntent.putExtra("score", score);

        startActivity(endGameIntent);



    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case MotionEvent.ACTION_DOWN:
                prevX = motionEvent.getX();
                prevY = motionEvent.getY();

                break;
            case MotionEvent.ACTION_UP:
                float newX = motionEvent.getX();
                float newY = motionEvent.getY();

                //calculate where we swiped
                if (Math.abs(newX - prevX) > Math.abs(newY - prevY)) {
                    //left - right direction
                    if (newX > prevX) {
                        //right
                        gameEngine.UpdateDirection(Direction.East);
                    } else {
                        //left
                        gameEngine.UpdateDirection(Direction.West);
                    }
                } else {
                    //up - down direction
                    if (newY > prevY) {
                        //down
                        gameEngine.UpdateDirection(Direction.South);
                    } else {
                        //up
                        gameEngine.UpdateDirection(Direction.North);
                    }
                }

                break;
        }

        return true;
    }
}
