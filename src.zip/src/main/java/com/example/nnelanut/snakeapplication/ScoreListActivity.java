//SCORE LIST ACTIVITY

package com.example.nnelanut.snakeapplication;

import android.content.Intent;
import android.content.res.Configuration;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.nnelanut.snakeapplication.classes.UserScore;

import java.util.ArrayList;

public class ScoreListActivity extends AppCompatActivity {

    private DatabaseManager dbManager;
    TextView scoreDisplay;
    String name;
    int score;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score_list);


        Bundle bundle = getIntent().getExtras();
        name = bundle.getString("name");
        score = bundle.getInt("score");
        UserScore newScore = new UserScore(name, score);

        dbManager = new DatabaseManager(this);
        dbManager.insert(newScore);


        scoreDisplay = (TextView) findViewById(R.id.scoreDisplay);



        Configuration config = getResources().getConfiguration();


       // onConfigurationChanged(config);

        updateView();



    }



    @Override
    protected void onResume() {
        super.onResume();
        updateView();
    }

    //UPDATES TEXT VIEW

    public void updateView() {

        ArrayList<UserScore> scoreArrayList = dbManager.selectAll();

        if (scoreArrayList.size() > 0) {

            String finalString = "\n";


            for (UserScore uS : scoreArrayList) {
                finalString += uS.getName() + ": " + uS.getScore() + "\n";
            }
            scoreDisplay.setText(finalString);
        }

    }

    //METHODS TO HANDLE CONFIGURATION CHANGES

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        modifyLayout(newConfig);
    }

    public void modifyLayout(Configuration config) {

        if(config.orientation == Configuration.ORIENTATION_PORTRAIT) {
            setContentView(R.layout.activity_score_list);
        }

        if(config.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setContentView(R.layout.activity_score_list_horizontal);
        }
    }


    public void returnToStart (View v) {

        Intent myIntent = new Intent(this, StartActivity.class);
        startActivity(myIntent);
    }
}
